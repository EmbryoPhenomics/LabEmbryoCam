# LabEmbryoCam software 

Software for controlling and interfacing the with LabEmbryoCam instrument, with built-in front-end web application and backend modules/drivers for controlling associated hardware and conducting image acquisitions. 